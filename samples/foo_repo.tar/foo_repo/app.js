var http = require('http');

http.createServer(function(req, res) {
    res.writeHead(200, { 'x-app': 'this is my app' });
    res.end('This is foo\n');
}).listen(process.env.port);
